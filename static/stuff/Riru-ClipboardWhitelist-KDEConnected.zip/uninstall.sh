# Remove riru configs

RIRU_MODULE_PATH="/data/misc/riru/modules"

rm -rf "$RIRU_MODULE_PATH/clipboard_whitelist"